import 'package:free_lunch_app/features/sendLunches/models/sendlunch.model.dart';
import 'package:free_lunch_app/features/sendLunches/repository/irepository.sendlunch.dart';

class SendLunchRepository extends IRepositorySendLunch {
  @override
  Future<dynamic> sendLunches(SendLunchItem sendLunchItem) async {
    return;
  }
}
